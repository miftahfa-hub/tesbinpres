# CBT Bina Prestasi

Ruang ujian CBT 50 soal pilihan ganda Matematika Fase C (kelas 5 dan 6).

- 50 soal diacak dari bank 100 soal: 15 mudah, 17 sedang, 18 sulit
- Batas waktu 40 menit (hitung mundur), otomatis selesai saat waktu habis
- Istirahat Tic Tac Toe lawan bot selama 90 detik setiap selesai 10 soal (waktu ujian berhenti saat bermain)
- Daftar nomor soal, tanda ragu-ragu, kata penyemangat, skor, dan pembahasan
- Satu file saja (`index.html`), tanpa server dan tanpa instalasi

## Cara memasang di GitHub Pages

1. Buat repositori baru di GitHub (misalnya `cbt-bina-prestasi`), pilih **Public**.
2. Klik **Add file > Upload files**, unggah `index.html` (dan `README.md`), lalu **Commit changes**.
3. Buka **Settings > Pages**. Pada **Build and deployment**, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
4. Tunggu 1 sampai 2 menit. Alamatnya: `https://NAMA-GITHUB-ANDA.github.io/cbt-bina-prestasi/`

## Catatan

- Jawaban siswa tersimpan di browser perangkat masing-masing. Nilai tidak dikirim ke mana pun.
- Kunci jawaban ada di dalam file, jadi cocok untuk latihan, bukan ujian tertutup.
- Mengubah jumlah soal, waktu ujian, atau lama istirahat: cari `PLAN`, `LIMIT`, dan `GAME_MS` di bagian `<script>` pada `index.html`.
